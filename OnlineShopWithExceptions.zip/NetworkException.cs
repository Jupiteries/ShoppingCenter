﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopWithExceptions
{
    class NetworkException : Exception
    {
        public NetworkException() : base("A network error occurred") { }

    }
}

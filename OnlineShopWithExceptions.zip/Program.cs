﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OnlineShopWithExceptions
{
    class Program
    {
        static async Task Main(string[] args)
        {
            ShoppingCart cart = new ShoppingCart();

            while (true)
            {
                Console.WriteLine("Enter item name (or 'done' to check out):");
                string itemName = Console.ReadLine();
                if (itemName.ToLower() == "done")
                {
                    break;
                }

                bool validInput = false;
                double itemPrice = 0;


                while (!validInput)
                {
                    Console.WriteLine("Enter item price:");
                    string input = Console.ReadLine();

                    if (double.TryParse(input, out itemPrice))
                    {
                        validInput = true;
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Please enter a price.");
                    }
                }
                cart.AddItem(new Item { Name = itemName, Price = itemPrice });
            }

            CheckoutService checkoutService = new CheckoutService();

            while (true)
            {
                try
                {
                    double totalPrice = await checkoutService.CheckoutAsync(cart.GetItems());
                    Console.WriteLine($"Total price: ${totalPrice}");
                    break;
                }
                catch (NetworkException)
                {
                    Console.WriteLine("A network error occurred during checkout. Do you want to try again? (y/n)");
                    string answer = Console.ReadLine();
                    if (answer.ToLower() == "n")
                    {
                        break;
                    }
                }
            }
            Console.WriteLine("Thank you for shopping!");
        }
    }
}

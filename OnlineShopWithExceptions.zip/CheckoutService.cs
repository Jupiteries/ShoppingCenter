﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShopWithExceptions
{
    class CheckoutService
    {
        public async Task<double> CheckoutAsync(List<Item> items)
        {
            Random random = new Random();
            if (random.Next(2) == 0)
            {
                throw new NetworkException();
            }

            double totalPrice = 0;
            foreach (var item in items)
            {
                totalPrice += item.Price;
            }

            return totalPrice;
        }
    }
}
